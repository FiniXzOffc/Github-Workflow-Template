const fs = require('fs')

// Setting Utama
global.owner = "6287701725776" //owner number
global.namabot = "𝗗𝗮𝗻𝗮𝗱𝘆𝗮𝗸𝘀𝗮𝗜𝘀𝗛𝗲𝗿𝗲🌺"
global.botname = "𝗗𝗮𝗻𝗮𝗱𝘆𝗮𝗸𝘀𝗮𝗜𝘀𝗛𝗲𝗿𝗲🌺"
global.version = "𝟮.𝟬"
global.ownername = "𝙳𝚊𝚗𝚊𝚍𝚢𝚊𝚔𝚜𝚊𝙳𝚎𝚟 𝚂𝚒𝚗𝚌𝚎-𝟷𝟿𝟾𝟶"
// Watermark
global.footer = "_DanadyaksaDev_" //footer section
global.packname = "Sticker By"
global.author = "DanadyaksaDev"

// Mode Bot
global.status = false //"self/public" section of the bot

// Saluran Whatsapp
global.idsaluran = "120363306176036510@newsletter"
global.namasaluran = "DanadyaksaDev"

// Image
global.thumbnail = 'https://pomf2.lain.la/f/asneyvzb.jpg'

//database 
global.urldb = ''; // kosongin aja tapi kalo mau pake database mongo db isi url mongo
global.themeemoji = '🔥'
//========= Setting Message =========//
global.msg = {
"error": "`</> Mohon Maaf Dek Fitur Error Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki`",
"success": "`</> 𝙎𝙪𝙘𝙘𝙚𝙨⚡`", 
"wait": "`</> 𝙋𝙧𝙤𝙘𝙚𝙨𝙨⚡`", 
"ingroup": "`</> 𝙂𝙧𝙤𝙪𝙥 𝙊𝙣𝙡𝙮!!!`",
"private": "`</> 𝙋𝙧𝙞𝙫𝙖𝙩 𝘾𝙝𝙖𝙩 𝙊𝙣𝙡𝙮!!!`", 
"admin": "`</> 𝙊𝙣𝙡𝙮 𝘼𝙙𝙢𝙞𝙣 𝘿𝙚𝙠`",
"adminbot": "`</> 𝙅𝘼𝘿𝙄𝙄𝙉 𝘼𝘿𝙈𝙄𝙉 𝘿𝙐𝙇𝙐 𝙂𝙊𝘽𝙇𝙊𝙆`",
"owner": "`</> 𝘼𝙥𝙖𝙨𝙞𝙝 𝙔𝙖𝙩𝙞𝙢!!!`", 
"prem": "`</> 𝗡𝗼 𝗔𝗰𝗰𝗲𝘀𝘀!!!`",
"developer": "`</> 𝙊𝙣𝙡𝙮 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧`",
"daftar": "𝗡𝗼 𝗔𝗰𝗰𝗲𝘀𝘀!!!, 𝗔𝗻𝗱𝗮 𝗕𝗲𝗹𝘂𝗺 𝗧𝗲𝗿𝗱𝗮𝗳𝘁𝗮𝗿 𝗗𝗶 𝗗𝗮𝘁𝗮𝗯𝗮𝘀𝗲 𝗞𝗮𝗺𝗶             𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 `[ /𝗱𝗮𝗳𝘁𝗮𝗿 ]` 𝗧𝗲𝗿𝗹𝗲𝗯𝗶𝗵 𝗗𝗮𝗵𝘂𝗹𝘂", 
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})